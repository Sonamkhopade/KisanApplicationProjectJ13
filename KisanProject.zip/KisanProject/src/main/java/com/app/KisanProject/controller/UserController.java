package com.app.KisanProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.KisanProject.dto.LoginDto;
import com.app.KisanProject.dto.SignUpDto;
import com.app.KisanProject.entity.UserRegistration;
import com.app.KisanProject.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping(value="/add")
	public ResponseEntity<UserRegistration> addUser(@RequestBody UserRegistration user){
		return new ResponseEntity<UserRegistration>(userService.addUser(user),HttpStatus.OK);
	}
	@PostMapping(value="/login")
	public ResponseEntity<LoginDto> login(@RequestBody LoginDto loginDto){
		return new ResponseEntity<LoginDto>(userService.login(loginDto),HttpStatus.OK);
	}
	@PostMapping(value="/signUp")
	public ResponseEntity<SignUpDto> signUpUser(@RequestBody SignUpDto signUpDto){
		return new ResponseEntity<SignUpDto>(userService.signUpUser(signUpDto),HttpStatus.OK);
	}
	@GetMapping(value="/userList")
	public ResponseEntity<List<UserRegistration>> getUser(){
		return new ResponseEntity<List<UserRegistration>>(userService.getUser(),HttpStatus.OK);
	}
	@GetMapping("/getById")
	public ResponseEntity<UserRegistration> getUSerById(@RequestParam long id){
		return new ResponseEntity<UserRegistration>(userService.getUserById(id),
				HttpStatus.OK);
	}
	@GetMapping("/getByName")
	public ResponseEntity<UserRegistration> getUserByName(@RequestParam String name){
		return new ResponseEntity<UserRegistration>(userService.getUserByName(name),
				HttpStatus.OK);
	}

}
