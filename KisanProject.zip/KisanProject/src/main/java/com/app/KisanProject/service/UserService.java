package com.app.KisanProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.KisanProject.dto.LoginDto;
import com.app.KisanProject.dto.SignUpDto;
import com.app.KisanProject.entity.UserRegistration;
import com.app.KisanProject.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository repo;
	LoginDto dto=new LoginDto();
	SignUpDto up=new SignUpDto();

	public UserRegistration addUser(UserRegistration user) {
		// TODO Auto-generated method stub
		return repo.save(user);
	}

	public LoginDto login(LoginDto loginDto) {
		// TODO Auto-generated method stub
		UserRegistration register=repo.findByemail(loginDto.getEmail());
		UserRegistration register1=repo.findByPassword(loginDto.getPassword());
		if(register!=null&& register1!=null) {
			dto.setEmail(loginDto.getEmail());
			dto.setPassword(loginDto.getPassword());
			dto.setStatus("success");
		}
		else {
			dto.setEmail(loginDto.getEmail());
			dto.setPassword(loginDto.getPassword());
			dto.setStatus("login failed...");
		}
		return dto;
	}

	public List<UserRegistration> getUser() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public SignUpDto signUpUser(SignUpDto signUpDto) {
		// TODO Auto-generated method stub
		UserRegistration register=repo.findByemail(signUpDto.getEmail());
		UserRegistration register1=repo.findByPassword(signUpDto.getPassword());
		UserRegistration register2=repo.findByname(signUpDto.getName());
		if(register!=null&&register1!=null&&register2!=null) {
			up.setName(signUpDto.getName());
			up.setEmail(signUpDto.getEmail());
			up.setPassword(signUpDto.getPassword());
			up.setStatus("signUp successfully...");
		}
		else {
			up.setName(signUpDto.getName());
			up.setEmail(signUpDto.getEmail());
			up.setPassword(signUpDto.getPassword());
			up.setStatus("signUp failed...");
		}
		return up;
	}

	public UserRegistration getUserById(long id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	public UserRegistration getUserByName(String name) {
		// TODO Auto-generated method stub
		return repo.findByname(name);
	}

}
