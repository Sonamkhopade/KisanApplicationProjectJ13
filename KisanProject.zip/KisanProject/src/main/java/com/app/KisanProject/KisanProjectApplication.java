package com.app.KisanProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KisanProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KisanProjectApplication.class, args);
		System.out.println("Server up...");
	}

}
