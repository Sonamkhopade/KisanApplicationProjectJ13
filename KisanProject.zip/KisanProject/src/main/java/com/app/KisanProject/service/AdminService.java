package com.app.KisanProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.KisanProject.entity.Admin;
import com.app.KisanProject.repository.AdminRepository;

@Service
public class AdminService {
	@Autowired
	private AdminRepository repo;

	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return repo.save(admin);
	}
	
	

}
